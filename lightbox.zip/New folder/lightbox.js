//function to include html popup code

function includePopUpHtml(){
    let html='<div id="vis_popup"><span id="close" onclick="closePopUp()"><img id="npop" src="New folder/close.png" alt=""></span><img id="leftarrow" src="New folder/left-arrow.png" alt=""><img id="rightarrow" src="New folder/right-arrow.png" alt=""><img id="mainPopImage" src="New folder/lightbox/pexels-pixabay-36717.jpg" alt=""></div>';

    let popdiv= document.createElement("div");
    popdiv.innerHTML=html;
    document.body.insertBefore(popdiv, document.body.firstChild)
}

let img;
let current;

//function to init plugin
function imagePopUpInit(target){
//select all images
  img=document.getElementsByClassName(target);
   for(var i=0; i<img.length;i++){

   img[i].style.cursor ='pointer';
    img[i].addEventListener("click",function(){
      document.getElementById("mainPopImage").src=this.src;
      document.getElementById("vis_popup").style.display='block';
      checkArrow();
})
}

includePopUpHtml();
 //next button
document.getElementById('rightarrow').addEventListener('click',function(){
    nextimg();
})
 //prev button
 document.getElementById('leftarrow').addEventListener('click',function(){
    previmg();
})

}
function closePopUp(){
    document.getElementById("mainPopImage").src="";
    document.getElementById("vis_popup").style.display='none';
}
 //next image
function nextimg(){
    getcurrentImage();
    current++;
    document.getElementById("mainPopImage").src=img[current].src;
    checkArrow()

}


 //prev image
function previmg(){
    getcurrentImage();
    current--;
    document.getElementById("mainPopImage").src=img[current].src;
    checkArrow()
}

function getcurrentImage(){
    for(var i=0; i< img.length; i++){
        if(img[i].src == document.getElementById("mainPopImage").src){
            current=i;
        }
    }
}


function checkArrow(){
    getcurrentImage();
    if(current == "0"){
        document.getElementById('leftarrow').style.display='none';
        document.getElementById('rightarrow').style.display='block';
    }else if(current== img.length-1){
        document.getElementById('rightarrow').style.display='none';
        document.getElementById('leftarrow').style.display='block';
    }else{
        document.getElementById('leftarrow').style.display='block';document.getElementById('rightarrow').style.display='block';
    }

}